# 💧 AguaVic - Monitor Comunitario de Tandeos
## Ciudad Victoria, Tamaulipas

---

## 📁 ESTRUCTURA DE ARCHIVOS

```
C:\xampp\htdocs\aguavic\
│
├── index.php         ← Frontend principal (toda la app)
├── api.php           ← API REST (todas las acciones del backend)
├── config.php        ← Configuración de base de datos
├── generar_pdf.php   ← Generador de reporte PDF para fugas
├── database.sql      ← Script de base de datos con datos de ejemplo
└── uploads/
    └── fugas/        ← Fotos de fugas (se crea automático)
```

---

## ⚙️ INSTALACIÓN PASO A PASO

### 1. Copiar archivos
Copia la carpeta `aguavic` completa a:
```
C:\xampp\htdocs\aguavic\
```

### 2. Crear la base de datos
1. Abre XAMPP → inicia **Apache** y **MySQL**
2. Ve a: http://localhost/phpmyadmin
3. Haz clic en **"Nueva"** (panel izquierdo)
4. Nombre: `aguavic` → Cotejamiento: `utf8mb4_unicode_ci` → **Crear**
5. Selecciona la base `aguavic` → pestaña **SQL**
6. Pega el contenido de `database.sql` → **Continuar**

### 3. Verificar config
Abre `config.php` y verifica:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');   // Tu usuario de MySQL
define('DB_PASS', '');       // Tu contraseña (vacía por defecto en XAMPP)
define('DB_NAME', 'aguavic');
```

### 4. Abrir la app
Navegador: http://localhost/aguavic/

---

## 📱 VER EN TELÉFONO (LAN)

Para acceder desde tu celular en la misma red WiFi:

1. Busca la IP de tu PC:
   - Windows: Abre CMD → escribe `ipconfig`
   - Busca **Dirección IPv4** (ej: `192.168.1.105`)

2. En tu celular, abre el navegador y entra a:
   ```
   http://192.168.1.105/aguavic/
   ```

3. Si no carga, verifica el Firewall de Windows:
   - Panel de Control → Firewall → Permitir app
   - Agrega `C:\xampp\apache\bin\httpd.exe`
   - Marca "Redes privadas"

---

## 👤 USUARIO ADMINISTRADOR (DE PRUEBA)

```
Email:    admin@aguavic.mx
Password: password
```
(Este es el usuario de prueba creado por el script SQL con karma=500/nivel=experto)

---

## 🔑 FUNCIONALIDADES IMPLEMENTADAS

✅ Búsqueda de colonias con autocompletado  
✅ Calendario semanal de horarios de tandeo  
✅ 3 botones de estado (Sin agua / Baja presión / Normal)  
✅ Mapa interactivo con Leaflet (colores según reportes últimas 2h)  
✅ Sistema de favoritos (requiere login)  
✅ Notificaciones push in-app cuando hay reportes de "sin agua"  
✅ Formulario de fugas con foto y captura de GPS  
✅ Generación de PDF oficial para fugas (imprimir / guardar)  
✅ Directorio con llamada directa y WhatsApp  
✅ Sistema de Karma y niveles de reputación  
✅ Porcentaje de cumplimiento semanal  
✅ Gráfica histórica 30 días (Chart.js)  
✅ Hora probable de regreso del agua  
✅ Firma digital ciudadana de fugas  
✅ Folio automático para fugas  
✅ Login / Registro (email o teléfono)  
✅ Panel admin con carga CSV de tandeos  
✅ Diseño 100% responsivo para móviles  

---

## 📊 FORMATO CSV PARA ADMIN

El archivo CSV debe tener este formato (sin encabezado, o con encabezado ignorado en línea 1):

```
colonia_nombre,dia_semana,hora_inicio,hora_fin
Centro Histórico,1,06:00,10:00
Centro Histórico,4,06:00,10:00
Colonia Libertad,2,07:00,11:00
```

Donde `dia_semana`: 0=Domingo, 1=Lunes, 2=Martes, ..., 6=Sábado

---

## 🗄️ TABLAS DE LA BASE DE DATOS

| Tabla | Descripción |
|-------|-------------|
| `colonias` | Colonias/fraccionamientos con coordenadas |
| `tandeos` | Horarios oficiales de tandeo por colonia |
| `usuarios` | Cuentas de usuario con karma y nivel |
| `favoritos` | Colonias favoritas por usuario |
| `reportes_estado` | Reportes Sin agua / Baja presión / Normal |
| `fugas` | Reportes de fugas con folio y foto |
| `firmas_fugas` | Firmas ciudadanas de reportes de fuga |
| `directorio_servicios` | Pipas, purificadoras, plomeros |
| `notificaciones` | Alertas push in-app |

---

## 🛠️ TECNOLOGÍAS

- **Frontend**: HTML5, CSS3, JavaScript vanilla
- **Backend**: PHP 8.x
- **Base de datos**: MySQL (MariaDB en XAMPP)
- **Mapa**: Leaflet.js + OpenStreetMap
- **Gráficas**: Chart.js
- **Fuentes**: Google Fonts (Barlow Condensed + Nunito)
- **PDF**: HTML imprimible (window.print → Guardar como PDF)

---

## 📝 NOTAS

- El sistema de notificaciones push es **in-app** (al abrir la app)
- El PDF se genera como HTML optimizado para impresión (Ctrl+P → Guardar PDF)
- Para notificaciones reales del sistema operativo se necesitaría Service Worker + HTTPS
- La carpeta `uploads/fugas/` se crea automáticamente al primer reporte con foto
