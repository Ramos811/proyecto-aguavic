<?php
require_once 'config.php';
$usuario = usuarioActual();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<meta name="theme-color" content="#0D47A1">
<meta name="description" content="AguaVic - Monitor comunitario de tandeos de agua en Ciudad Victoria">
<title>AguaVic – Monitor de Tandeos</title>

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800&family=Nunito:wght@400;500;600;700&display=swap" rel="stylesheet">

<!-- Leaflet Map -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<style>
/* ============================================================
   VARIABLES Y RESET
   ============================================================ */
:root {
  --azul:       #0D47A1;
  --azul-m:     #1565C0;
  --azul-l:     #1976D2;
  --azul-xl:    #42A5F5;
  --cielo:      #E3F2FD;
  --rojo:       #C62828;
  --amarillo:   #F9A825;
  --verde:      #2E7D32;
  --fondo:      #F0F7FF;
  --blanco:     #FFFFFF;
  --gris-texto: #37474F;
  --gris-claro: #ECEFF1;
  --sombra:     0 2px 12px rgba(13,71,161,.13);
  --radio:      14px;
  --radio-sm:   8px;
  font-size: 15px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
html,body{width:100%;min-height:100%;overflow-x:hidden;}
body{font-family:'Nunito',sans-serif;background:var(--fondo);color:var(--gris-texto);padding-bottom:80px;}

/* ============================================================
   HEADER
   ============================================================ */
.app-header{
  background: linear-gradient(135deg, #0D47A1 0%, #1976D2 60%, #29B6F6 100%);
  color:white;padding:0;position:sticky;top:0;z-index:100;box-shadow:0 2px 12px rgba(0,0,0,.25);
}
.header-inner{display:flex;align-items:center;gap:10px;padding:10px 16px;}
.logo{font-family:'Barlow Condensed',sans-serif;font-weight:800;font-size:1.9rem;letter-spacing:2px;line-height:1;}
.logo span{color:#90CAF9;}
.header-sub{font-size:.72rem;opacity:.85;margin-top:2px;letter-spacing:.5px;}
.header-right{margin-left:auto;display:flex;align-items:center;gap:10px;}
.btn-notif{position:relative;background:rgba(255,255,255,.15);border:none;color:white;width:40px;height:40px;border-radius:50%;cursor:pointer;font-size:1.1rem;display:flex;align-items:center;justify-content:center;}
.btn-notif .badge{position:absolute;top:-2px;right:-2px;background:var(--rojo);color:white;border-radius:50%;width:17px;height:17px;font-size:.6rem;display:flex;align-items:center;justify-content:center;font-weight:700;}
.btn-login-hdr{background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.4);color:white;padding:6px 14px;border-radius:20px;cursor:pointer;font-size:.8rem;font-family:'Nunito',sans-serif;font-weight:600;}
.avatar-hdr{background:rgba(255,255,255,.25);border:none;color:white;padding:5px 12px;border-radius:20px;cursor:pointer;font-size:.8rem;font-family:'Nunito',sans-serif;font-weight:700;display:flex;align-items:center;gap:6px;}

/* ============================================================
   SEARCH BAR
   ============================================================ */
.search-section{padding:14px 16px 0;}
.search-wrap{position:relative;}
.search-input{width:100%;padding:12px 44px 12px 16px;border:2px solid #BBDEFB;border-radius:30px;font-size:1rem;font-family:'Nunito',sans-serif;background:white;outline:none;transition:border .2s,box-shadow .2s;color:var(--gris-texto);}
.search-input:focus{border-color:var(--azul-l);box-shadow:0 0 0 3px rgba(25,118,210,.15);}
.search-icon{position:absolute;right:14px;top:50%;transform:translateY(-50%);font-size:1.1rem;color:var(--azul-l);pointer-events:none;}
.autocomplete-list{position:absolute;top:calc(100% + 6px);left:0;right:0;background:white;border-radius:var(--radio-sm);box-shadow:0 6px 24px rgba(0,0,0,.15);z-index:200;max-height:220px;overflow-y:auto;display:none;}
.autocomplete-list.show{display:block;}
.autocomplete-item{padding:11px 16px;cursor:pointer;border-bottom:1px solid var(--gris-claro);display:flex;align-items:center;gap:10px;font-size:.95rem;}
.autocomplete-item:last-child{border-bottom:none;}
.autocomplete-item:hover,.autocomplete-item.active{background:var(--cielo);}
.autocomplete-item .sector{font-size:.78rem;color:#90A4AE;margin-left:auto;}

/* ============================================================
   NAV TABS
   ============================================================ */
.nav-tabs{display:flex;overflow-x:auto;gap:6px;padding:10px 16px;scrollbar-width:none;-ms-overflow-style:none;}
.nav-tabs::-webkit-scrollbar{display:none;}
.nav-tab{flex-shrink:0;padding:8px 14px;border-radius:20px;border:2px solid #BBDEFB;background:white;color:var(--azul-m);font-size:.82rem;font-weight:700;font-family:'Nunito',sans-serif;cursor:pointer;transition:.2s;white-space:nowrap;}
.nav-tab.active,.nav-tab:hover{background:var(--azul-m);color:white;border-color:var(--azul-m);}

/* ============================================================
   PANELS
   ============================================================ */
.panel{display:none;padding:0 16px;}
.panel.active{display:block;}

/* ============================================================
   TARJETA COLONIA SELECCIONADA
   ============================================================ */
.colonia-card{background:white;border-radius:var(--radio);padding:16px;margin-bottom:14px;box-shadow:var(--sombra);border-top:4px solid var(--azul-l);}
.colonia-title{font-family:'Barlow Condensed',sans-serif;font-size:1.5rem;font-weight:700;color:var(--azul);letter-spacing:.5px;}
.colonia-sector{font-size:.82rem;color:#78909C;margin-top:2px;}
.cumplimiento-bar{margin-top:10px;}
.cumplimiento-label{display:flex;justify-content:space-between;font-size:.8rem;color:#546E7A;margin-bottom:4px;}
.bar-track{height:8px;background:#E0E0E0;border-radius:4px;overflow:hidden;}
.bar-fill{height:100%;border-radius:4px;transition:width .6s ease;}
.hora-probable{margin-top:10px;padding:8px 12px;background:var(--cielo);border-radius:8px;font-size:.85rem;color:var(--azul-m);display:flex;align-items:center;gap:8px;}

/* ============================================================
   BOTONES DE ESTADO
   ============================================================ */
.estado-btns{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:14px;}
.estado-btn{padding:12px 6px;border:2px solid transparent;border-radius:var(--radio-sm);font-family:'Nunito',sans-serif;font-size:.82rem;font-weight:700;cursor:pointer;text-align:center;transition:.2s;background:white;}
.estado-btn .icon{font-size:1.5rem;display:block;margin-bottom:4px;}
.estado-btn.sin-agua{border-color:#EF9A9A;color:var(--rojo);}
.estado-btn.baja-presion{border-color:#FFE082;color:#E65100;}
.estado-btn.normal{border-color:#A5D6A7;color:var(--verde);}
.estado-btn.sin-agua:hover,.estado-btn.sin-agua.selected{background:var(--rojo);color:white;border-color:var(--rojo);}
.estado-btn.baja-presion:hover,.estado-btn.baja-presion.selected{background:var(--amarillo);color:white;border-color:var(--amarillo);}
.estado-btn.normal:hover,.estado-btn.normal.selected{background:var(--verde);color:white;border-color:var(--verde);}

/* ============================================================
   CALENDARIO TANDEOS
   ============================================================ */
.calendario{background:white;border-radius:var(--radio);padding:14px;margin-bottom:14px;box-shadow:var(--sombra);}
.sec-title{font-family:'Barlow Condensed',sans-serif;font-size:1.1rem;font-weight:700;color:var(--azul);margin-bottom:10px;display:flex;align-items:center;gap:8px;}
.dias-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:4px;}
.dia-cell{text-align:center;border-radius:6px;padding:6px 2px;background:var(--gris-claro);min-height:64px;}
.dia-cell.tiene-tandeo{background:var(--cielo);border:1.5px solid #90CAF9;}
.dia-cell.hoy{border-color:var(--azul-l)!important;background:linear-gradient(135deg,#E3F2FD,#BBDEFB)!important;}
.dia-nombre{font-size:.65rem;font-weight:700;color:#78909C;text-transform:uppercase;}
.dia-cell.tiene-tandeo .dia-nombre{color:var(--azul-m);}
.dia-horario{font-size:.6rem;color:var(--azul);font-weight:700;margin-top:2px;line-height:1.3;}
.dia-icon{font-size:.9rem;}

/* ============================================================
   MAPA
   ============================================================ */
#mapa{width:100%;height:320px;border-radius:var(--radio);overflow:hidden;box-shadow:var(--sombra);}
.mapa-leyenda{display:flex;gap:12px;margin:8px 0;flex-wrap:wrap;}
.leyenda-item{display:flex;align-items:center;gap:5px;font-size:.8rem;color:#546E7A;}
.leyenda-color{width:12px;height:12px;border-radius:50%;border:1px solid rgba(0,0,0,.1);}

/* ============================================================
   TARJETA FUGA
   ============================================================ */
.fuga-card{background:white;border-radius:var(--radio);padding:14px;margin-bottom:10px;box-shadow:var(--sombra);border-left:4px solid var(--rojo);}
.fuga-folio{font-family:'Barlow Condensed',sans-serif;font-size:1.1rem;font-weight:700;color:var(--azul);letter-spacing:1px;}
.fuga-meta{font-size:.8rem;color:#78909C;margin:2px 0 8px;}
.fuga-desc{font-size:.88rem;color:var(--gris-texto);margin-bottom:8px;}
.fuga-actions{display:flex;gap:8px;flex-wrap:wrap;}
.badge-firmas{background:var(--cielo);color:var(--azul-m);padding:3px 10px;border-radius:20px;font-size:.8rem;font-weight:700;}
.btn-firmar{background:var(--azul-m);color:white;border:none;padding:6px 14px;border-radius:20px;font-size:.82rem;font-family:'Nunito',sans-serif;font-weight:700;cursor:pointer;}
.btn-pdf{background:white;color:var(--rojo);border:1.5px solid var(--rojo);padding:6px 12px;border-radius:20px;font-size:.8rem;font-family:'Nunito',sans-serif;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:4px;}
.estado-tag{display:inline-block;padding:2px 10px;border-radius:10px;font-size:.75rem;font-weight:700;}
.tag-abierto{background:#FFCDD2;color:#B71C1C;}
.tag-proceso{background:#FFF9C4;color:#F57F17;}
.tag-resuelto{background:#C8E6C9;color:#1B5E20;}

/* ============================================================
   DIRECTORIO
   ============================================================ */
.cat-btns{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;}
.cat-btn{padding:7px 14px;border-radius:20px;border:2px solid #BBDEFB;background:white;color:var(--azul-m);font-size:.82rem;font-weight:700;font-family:'Nunito',sans-serif;cursor:pointer;transition:.2s;}
.cat-btn.active,.cat-btn:hover{background:var(--azul-m);color:white;border-color:var(--azul-m);}
.servicio-card{background:white;border-radius:var(--radio-sm);padding:12px;margin-bottom:8px;box-shadow:0 1px 6px rgba(0,0,0,.08);display:flex;align-items:flex-start;gap:12px;}
.servicio-icon{width:40px;height:40px;border-radius:10px;background:var(--cielo);display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.servicio-info{flex:1;}
.servicio-nombre{font-weight:700;font-size:.95rem;color:var(--gris-texto);}
.servicio-desc{font-size:.78rem;color:#78909C;margin:1px 0 6px;}
.servicio-btns{display:flex;gap:6px;}
.btn-llamar{background:var(--verde);color:white;border:none;padding:5px 12px;border-radius:20px;font-size:.78rem;font-family:'Nunito',sans-serif;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:4px;}
.btn-whatsapp{background:#25D366;color:white;border:none;padding:5px 12px;border-radius:20px;font-size:.78rem;font-family:'Nunito',sans-serif;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:4px;}

/* ============================================================
   FORMS
   ============================================================ */
.form-group{margin-bottom:12px;}
.form-group label{display:block;font-size:.82rem;font-weight:700;color:var(--azul-m);margin-bottom:4px;}
.form-group input,.form-group textarea,.form-group select{width:100%;padding:10px 14px;border:2px solid #BBDEFB;border-radius:var(--radio-sm);font-size:.95rem;font-family:'Nunito',sans-serif;outline:none;transition:.2s;background:white;color:var(--gris-texto);}
.form-group input:focus,.form-group textarea:focus{border-color:var(--azul-l);box-shadow:0 0 0 3px rgba(25,118,210,.12);}
.form-group textarea{resize:vertical;min-height:80px;}
.btn-primary{width:100%;background:linear-gradient(135deg,var(--azul-m),var(--azul-l));color:white;border:none;padding:13px;border-radius:30px;font-size:1rem;font-weight:700;font-family:'Nunito',sans-serif;cursor:pointer;transition:.15s;letter-spacing:.5px;}
.btn-primary:hover{opacity:.9;}
.btn-primary:active{transform:scale(.98);}
.btn-secondary{width:100%;background:white;color:var(--azul-m);border:2px solid var(--azul-m);padding:11px;border-radius:30px;font-size:.95rem;font-weight:700;font-family:'Nunito',sans-serif;cursor:pointer;transition:.15s;}

/* ============================================================
   MODAL
   ============================================================ */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:500;display:none;align-items:flex-end;justify-content:center;}
.modal-overlay.show{display:flex;}
.modal{background:white;border-radius:20px 20px 0 0;padding:20px 20px 30px;width:100%;max-width:480px;max-height:90vh;overflow-y:auto;animation:slideUp .3s ease;}
@keyframes slideUp{from{transform:translateY(30px);opacity:0;}to{transform:translateY(0);opacity:1;}}
.modal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;}
.modal-title{font-family:'Barlow Condensed',sans-serif;font-size:1.4rem;font-weight:700;color:var(--azul);}
.modal-close{background:var(--gris-claro);border:none;width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;}

/* ============================================================
   TOAST
   ============================================================ */
.toast{position:fixed;bottom:90px;left:50%;transform:translateX(-50%) translateY(40px);background:#323232;color:white;padding:10px 20px;border-radius:30px;font-size:.88rem;z-index:999;opacity:0;transition:.3s;pointer-events:none;white-space:nowrap;}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
.toast.success{background:var(--verde);}
.toast.error{background:var(--rojo);}

/* ============================================================
   KARMA / PERFIL
   ============================================================ */
.karma-card{background:linear-gradient(135deg,var(--azul),var(--azul-l));color:white;border-radius:var(--radio);padding:16px;margin-bottom:14px;}
.karma-nombre{font-family:'Barlow Condensed',sans-serif;font-size:1.5rem;font-weight:800;}
.karma-nivel{display:inline-block;background:rgba(255,255,255,.2);padding:3px 12px;border-radius:20px;font-size:.8rem;margin-top:4px;}
.karma-puntos{font-size:2.5rem;font-weight:800;margin:8px 0 0;line-height:1;}
.karma-sub{font-size:.75rem;opacity:.8;}
.karma-barra{height:8px;background:rgba(255,255,255,.2);border-radius:4px;margin-top:10px;overflow:hidden;}
.karma-fill{height:100%;background:white;border-radius:4px;transition:width .8s ease;}

/* ============================================================
   TABS DE AUTH (login/registro)
   ============================================================ */
.auth-tabs{display:flex;gap:0;margin-bottom:16px;border-radius:var(--radio-sm);overflow:hidden;border:2px solid #BBDEFB;}
.auth-tab{flex:1;padding:9px;text-align:center;font-weight:700;font-size:.9rem;cursor:pointer;background:white;color:var(--azul-m);border:none;font-family:'Nunito',sans-serif;}
.auth-tab.active{background:var(--azul-m);color:white;}

/* ============================================================
   NOTIFICACIONES PANEL
   ============================================================ */
.notif-item{background:white;border-radius:var(--radio-sm);padding:12px;margin-bottom:8px;box-shadow:0 1px 6px rgba(0,0,0,.07);border-left:3px solid var(--azul-xl);display:flex;gap:10px;}
.notif-item.no-leida{border-left-color:var(--rojo);}
.notif-icon{font-size:1.3rem;}
.notif-texto{font-size:.87rem;color:var(--gris-texto);flex:1;}
.notif-hora{font-size:.75rem;color:#90A4AE;margin-top:3px;}

/* ============================================================
   HISTORICO / GRÁFICAS
   ============================================================ */
.chart-wrap{background:white;border-radius:var(--radio);padding:14px;margin-bottom:14px;box-shadow:var(--sombra);}

/* ============================================================
   EMPTY STATE
   ============================================================ */
.empty{text-align:center;padding:30px 20px;color:#90A4AE;}
.empty .icon{font-size:2.5rem;margin-bottom:8px;}
.empty p{font-size:.9rem;}

/* ============================================================
   FAB BUTTON
   ============================================================ */
.fab{position:fixed;bottom:20px;right:16px;width:56px;height:56px;background:linear-gradient(135deg,var(--azul),var(--azul-l));color:white;border:none;border-radius:50%;font-size:1.5rem;cursor:pointer;box-shadow:0 4px 16px rgba(13,71,161,.35);z-index:90;display:flex;align-items:center;justify-content:center;}

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media(min-width:600px){
  body{padding-bottom:20px;}
  .app-header .header-inner{padding:10px 24px;}
  .search-section{padding:16px 24px 0;}
  .nav-tabs{padding:10px 24px;}
  .panel{padding:0 24px;}
  #mapa{height:420px;}
  .dias-grid{gap:6px;}
  .dia-nombre{font-size:.72rem;}
  .dia-horario{font-size:.68rem;}
}
@media(min-width:900px){
  .app-container{max-width:720px;margin:0 auto;}
  .header-inner{max-width:720px;margin:0 auto;}
  .search-section,.nav-tabs,.panel{max-width:720px;margin-left:auto;margin-right:auto;}
}
</style>
</head>
<body>

<!-- HEADER -->
<header class="app-header">
  <div class="header-inner">
    <div>
      <div class="logo">💧 Agua<span>Vic</span></div>
      <div class="header-sub">Monitor Comunitario · Ciudad Victoria</div>
    </div>
    <div class="header-right">
      <button class="btn-notif" id="btnNotif" title="Notificaciones" onclick="abrirNotificaciones()">
        🔔<span class="badge" id="badgeNotif" style="display:none">0</span>
      </button>
      <?php if ($usuario): ?>
        <button class="avatar-hdr" onclick="mostrarTab('perfil')">👤 <?= htmlspecialchars(explode(' ', $usuario['nombre'])[0]) ?></button>
      <?php else: ?>
        <button class="btn-login-hdr" onclick="abrirModal('modalAuth')">Entrar</button>
      <?php endif; ?>
    </div>
  </div>
</header>

<!-- SEARCH -->
<div class="search-section">
  <div class="search-wrap">
    <input type="text" class="search-input" id="searchColonia" placeholder="Busca tu colonia o fraccionamiento..." autocomplete="off">
    <span class="search-icon">🔍</span>
    <div class="autocomplete-list" id="autocompleteList"></div>
  </div>
</div>

<!-- NAV TABS -->
<nav class="nav-tabs">
  <button class="nav-tab active" onclick="mostrarTab('inicio')">🏠 Inicio</button>
  <button class="nav-tab" onclick="mostrarTab('mapa')">🗺️ Mapa</button>
  <button class="nav-tab" onclick="mostrarTab('fugas')">🚨 Fugas</button>
  <button class="nav-tab" onclick="mostrarTab('directorio')">📞 Directorio</button>
  <button class="nav-tab" onclick="mostrarTab('historico')">📊 Histórico</button>
  <button class="nav-tab" onclick="mostrarTab('perfil')">👤 Perfil</button>
</nav>

<!-- ============================================================
     PANEL: INICIO
     ============================================================ -->
<div class="panel active" id="panel-inicio">

  <!-- Colonia seleccionada -->
  <div id="coloniaInfo" style="display:none;">
    <div class="colonia-card" id="coloniaCard">
      <div class="colonia-title" id="coloniaNombre">—</div>
      <div class="colonia-sector" id="coloniaSector">—</div>
      <div class="cumplimiento-bar" id="cumplimientoWrap">
        <div class="cumplimiento-label"><span>Cumplimiento semanal</span><span id="cumplimientoPct">—</span></div>
        <div class="bar-track"><div class="bar-fill" id="cumplimientoBar" style="width:0%;background:var(--verde);"></div></div>
      </div>
      <div class="hora-probable" id="horaProbable" style="display:none;">
        ⏰ <span id="horaProbableTexto"></span>
      </div>
    </div>

    <!-- Botones de estado -->
    <div class="estado-btns">
      <button class="estado-btn sin-agua" onclick="registrarEstado('sin_agua',this)">
        <span class="icon">🔴</span>Sin agua
      </button>
      <button class="estado-btn baja-presion" onclick="registrarEstado('baja_presion',this)">
        <span class="icon">🟡</span>Baja presión
      </button>
      <button class="estado-btn normal" onclick="registrarEstado('normal',this)">
        <span class="icon">🟢</span>Presión normal
      </button>
    </div>
    <p style="font-size:.75rem;color:#90A4AE;text-align:center;margin-bottom:12px;">Tu reporte ayuda al mapa comunitario 💪</p>

    <!-- Calendario tandeos -->
    <div class="calendario">
      <div class="sec-title">📅 Horarios Oficiales de Tandeo</div>
      <div class="dias-grid" id="calendarioTandeos"></div>
    </div>
  </div>

  <div id="bienvenidaMsg" style="text-align:center;padding:30px 20px;color:#78909C;">
    <div style="font-size:3rem;">💧</div>
    <p style="font-size:1.1rem;font-weight:700;color:var(--azul);margin-bottom:6px;">Bienvenido a AguaVic</p>
    <p style="font-size:.9rem;">Busca tu colonia arriba para ver los horarios de tandeo y reportar el estado del agua.</p>
  </div>
</div>

<!-- ============================================================
     PANEL: MAPA
     ============================================================ -->
<div class="panel" id="panel-mapa">
  <div style="margin:14px 0 8px;">
    <div class="sec-title">🗺️ Estado Actual de la Ciudad</div>
    <div class="mapa-leyenda">
      <div class="leyenda-item"><div class="leyenda-color" style="background:#C62828;"></div> Sin agua</div>
      <div class="leyenda-item"><div class="leyenda-color" style="background:#F9A825;"></div> Baja presión</div>
      <div class="leyenda-item"><div class="leyenda-color" style="background:#2E7D32;"></div> Normal</div>
      <div class="leyenda-item"><div class="leyenda-color" style="background:#90A4AE;"></div> Sin reportes</div>
    </div>
    <div id="mapa"></div>
    <p style="font-size:.75rem;color:#90A4AE;margin-top:6px;text-align:center;">Basado en reportes de las últimas 2 horas · Toca un punto para ver detalles</p>
  </div>
</div>

<!-- ============================================================
     PANEL: FUGAS
     ============================================================ -->
<div class="panel" id="panel-fugas">
  <div style="margin:14px 0 12px;display:flex;align-items:center;justify-content:space-between;">
    <div class="sec-title">🚨 Reportes de Fugas</div>
    <button class="btn-primary" style="width:auto;padding:8px 16px;font-size:.82rem;" onclick="abrirModal('modalFuga')">+ Reportar</button>
  </div>

  <div id="listaFugas">
    <div class="empty"><div class="icon">🔍</div><p>Cargando reportes...</p></div>
  </div>
</div>

<!-- ============================================================
     PANEL: DIRECTORIO
     ============================================================ -->
<div class="panel" id="panel-directorio">
  <div style="margin:14px 0 10px;">
    <div class="sec-title">📞 Directorio de Servicios</div>
    <div class="cat-btns">
      <button class="cat-btn active" onclick="cargarDirectorio('')" data-cat="">Todos</button>
      <button class="cat-btn" onclick="cargarDirectorio('pipas')" data-cat="pipas">🚚 Pipas</button>
      <button class="cat-btn" onclick="cargarDirectorio('purificadoras')" data-cat="purificadoras">💧 Purificadoras</button>
      <button class="cat-btn" onclick="cargarDirectorio('plomeros')" data-cat="plomeros">🔧 Plomeros</button>
    </div>
    <div id="listaDirectorio"></div>
  </div>
</div>

<!-- ============================================================
     PANEL: HISTÓRICO
     ============================================================ -->
<div class="panel" id="panel-historico">
  <div style="margin:14px 0 10px;">
    <div class="sec-title">📊 Histórico de Servicio</div>
    <div id="historicoColonia" style="text-align:center;padding:20px;color:#90A4AE;">
      <p>Selecciona una colonia en la barra de búsqueda para ver su historial.</p>
    </div>
    <div class="chart-wrap" id="grafica30Container" style="display:none;">
      <div class="sec-title" style="margin-bottom:8px;">📈 Reportes últimos 30 días</div>
      <canvas id="grafica30" height="200"></canvas>
    </div>
  </div>
</div>

<!-- ============================================================
     PANEL: PERFIL
     ============================================================ -->
<div class="panel" id="panel-perfil">
  <div style="margin:14px 0;">
    <?php if ($usuario): ?>
    <div class="karma-card">
      <div class="karma-nombre">👤 <?= htmlspecialchars($usuario['nombre']) ?></div>
      <div class="karma-nivel">⭐ <?= ucfirst($usuario['nivel_reputacion']) ?></div>
      <div class="karma-puntos"><?= $usuario['karma'] ?></div>
      <div class="karma-sub">puntos de karma</div>
      <div class="karma-barra"><div class="karma-fill" id="karmaFill"></div></div>
    </div>

    <div class="sec-title" style="margin-bottom:10px;">⭐ Colonias Favoritas</div>
    <div id="listaFavoritos"></div>

    <?php if ($usuario['nivel_reputacion'] === 'experto'): ?>
    <div style="margin-top:16px;background:white;border-radius:var(--radio);padding:14px;box-shadow:var(--sombra);border-top:4px solid var(--azul);">
      <div class="sec-title">🔧 Panel Administrador</div>
      <p style="font-size:.83rem;color:#546E7A;margin-bottom:10px;">Carga masiva de horarios oficiales via CSV.<br>Formato: <code>colonia_nombre, dia(0-6), hora_inicio(HH:MM), hora_fin(HH:MM)</code></p>
      <input type="file" id="csvFile" accept=".csv" class="form-group" style="margin-bottom:10px;">
      <button class="btn-primary" onclick="subirCSV()">📁 Cargar CSV de Tandeos</button>
      <div id="csvResultado" style="margin-top:10px;font-size:.82rem;"></div>
    </div>
    <?php endif; ?>

    <div style="margin-top:14px;">
      <button class="btn-secondary" onclick="cerrarSesion()">🚪 Cerrar Sesión</button>
    </div>

    <?php else: ?>
    <div style="text-align:center;padding:30px 20px;">
      <div style="font-size:3rem;margin-bottom:10px;">👤</div>
      <p style="font-weight:700;font-size:1.1rem;color:var(--azul);margin-bottom:6px;">Inicia sesión para más funciones</p>
      <p style="font-size:.9rem;color:#78909C;margin-bottom:16px;">Guarda tus colonias favoritas, gana karma y recibe notificaciones.</p>
      <button class="btn-primary" onclick="abrirModal('modalAuth')">Entrar / Registrarse</button>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- ============================================================
     MODAL: AUTH (Login / Registro)
     ============================================================ -->
<div class="modal-overlay" id="modalAuth">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">💧 AguaVic</div>
      <button class="modal-close" onclick="cerrarModal('modalAuth')">✕</button>
    </div>
    <div class="auth-tabs">
      <button class="auth-tab active" id="tabLoginBtn" onclick="switchAuth('login')">Iniciar Sesión</button>
      <button class="auth-tab" id="tabRegBtn" onclick="switchAuth('registro')">Registrarse</button>
    </div>

    <!-- Login -->
    <div id="formLogin">
      <div class="form-group">
        <label>Correo o teléfono</label>
        <input type="text" id="loginId" placeholder="tu@correo.com o 8341234567">
      </div>
      <div class="form-group">
        <label>Contraseña</label>
        <input type="password" id="loginPass" placeholder="Tu contraseña">
      </div>
      <button class="btn-primary" onclick="doLogin()">Entrar</button>
    </div>

    <!-- Registro -->
    <div id="formRegistro" style="display:none;">
      <div class="form-group">
        <label>Nombre completo</label>
        <input type="text" id="regNombre" placeholder="Tu nombre">
      </div>
      <div class="form-group">
        <label>Correo electrónico</label>
        <input type="email" id="regEmail" placeholder="tu@correo.com">
      </div>
      <div class="form-group">
        <label>Teléfono (opcional)</label>
        <input type="tel" id="regTel" placeholder="8341234567">
      </div>
      <div class="form-group">
        <label>Contraseña (mín. 6 caracteres)</label>
        <input type="password" id="regPass" placeholder="Contraseña segura">
      </div>
      <button class="btn-primary" onclick="doRegistro()">Crear cuenta</button>
    </div>
  </div>
</div>

<!-- ============================================================
     MODAL: REPORTAR FUGA
     ============================================================ -->
<div class="modal-overlay" id="modalFuga">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">🚨 Reportar Fuga</div>
      <button class="modal-close" onclick="cerrarModal('modalFuga')">✕</button>
    </div>
    <div class="form-group">
      <label>Colonia (escribe para buscar)</label>
      <select id="fugaColonia">
        <option value="">Selecciona una colonia...</option>
        <?php
        $db = getDB();
        $cols = $db->query("SELECT id, nombre FROM colonias ORDER BY nombre")->fetchAll();
        foreach ($cols as $c) {
            echo '<option value="' . $c['id'] . '">' . htmlspecialchars($c['nombre']) . '</option>';
        }
        ?>
      </select>
    </div>
    <div class="form-group">
      <label>Descripción del problema</label>
      <textarea id="fugaDesc" placeholder="Describe la fuga, su tamaño, desde cuándo..."></textarea>
    </div>
    <div class="form-group">
      <label>📸 Fotografía (opcional)</label>
      <input type="file" id="fugaFoto" accept="image/*" capture="environment">
    </div>
    <div id="fugaGPSInfo" style="font-size:.8rem;color:#78909C;margin-bottom:12px;padding:8px;background:var(--cielo);border-radius:6px;display:none;">
      📍 <span id="fugaGPSTexto">Obteniendo ubicación GPS...</span>
    </div>
    <button class="btn-primary" onclick="obtenerGPSYEnviar()">📤 Enviar Reporte</button>
  </div>
</div>

<!-- ============================================================
     MODAL: NOTIFICACIONES
     ============================================================ -->
<div class="modal-overlay" id="modalNotif">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">🔔 Notificaciones</div>
      <button class="modal-close" onclick="cerrarModal('modalNotif')">✕</button>
    </div>
    <div id="listaNotif"></div>
  </div>
</div>

<!-- TOAST -->
<div class="toast" id="toastMsg"></div>

<!-- FAB: Reporte rápido (visible en mapa y fugas) -->
<button class="fab" id="fabBtn" onclick="abrirModal('modalFuga')" title="Reportar fuga" style="display:none;">🚨</button>

<!-- ============================================================
     JAVASCRIPT
     ============================================================ -->
<script>
// ============================================================
// UTILIDADES
// ============================================================
const API = 'api.php';

async function apiFetch(params = {}, method = 'GET', formData = null) {
  let url = API;
  if (method === 'GET' && params) {
    const qs = new URLSearchParams(params).toString();
    url += '?' + qs;
  }
  const opts = { method, headers: {} };
  if (formData) {
    opts.body = formData;
  } else if (method === 'POST' && params) {
    opts.headers['Content-Type'] = 'application/x-www-form-urlencoded';
    opts.body = new URLSearchParams(params).toString();
  }
  const res = await fetch(url, opts);
  return res.json().catch(() => ({ error: 'Error de respuesta' }));
}

function toast(msg, tipo = '') {
  const t = document.getElementById('toastMsg');
  t.textContent = msg;
  t.className = 'toast show ' + tipo;
  setTimeout(() => t.className = 'toast', 3000);
}

function abrirModal(id) { document.getElementById(id).classList.add('show'); }
function cerrarModal(id) { document.getElementById(id).classList.remove('show'); }

// Cerrar modal al tocar overlay
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', e => { if (e.target === el) cerrarModal(el.id); });
});

// ============================================================
// TABS
// ============================================================
let tabActual = 'inicio';
function mostrarTab(tab) {
  tabActual = tab;
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  document.getElementById('panel-' + tab).classList.add('active');
  const idx = ['inicio','mapa','fugas','directorio','historico','perfil'].indexOf(tab);
  if (idx >= 0) document.querySelectorAll('.nav-tab')[idx].classList.add('active');

  const fab = document.getElementById('fabBtn');
  fab.style.display = ['mapa','fugas'].includes(tab) ? 'flex' : 'none';

  if (tab === 'mapa') { setTimeout(() => mapa && mapa.invalidateSize(), 100); cargarMapa(); }
  if (tab === 'fugas') cargarFugas();
  if (tab === 'directorio') cargarDirectorio('');
  if (tab === 'perfil') cargarPerfil();
}

// ============================================================
// BÚSQUEDA CON AUTOCOMPLETADO
// ============================================================
let coloniaSeleccionada = null;
let searchTimer = null;

document.getElementById('searchColonia').addEventListener('input', function() {
  clearTimeout(searchTimer);
  const q = this.value.trim();
  if (q.length < 2) { document.getElementById('autocompleteList').classList.remove('show'); return; }
  searchTimer = setTimeout(() => buscarColonias(q), 250);
});

document.getElementById('searchColonia').addEventListener('keydown', function(e) {
  const list = document.getElementById('autocompleteList');
  const items = list.querySelectorAll('.autocomplete-item');
  const active = list.querySelector('.autocomplete-item.active');
  if (e.key === 'ArrowDown') {
    const next = active ? (active.nextElementSibling || items[0]) : items[0];
    if (active) active.classList.remove('active');
    if (next) next.classList.add('active');
    e.preventDefault();
  } else if (e.key === 'ArrowUp') {
    const prev = active ? (active.previousElementSibling || items[items.length-1]) : items[items.length-1];
    if (active) active.classList.remove('active');
    if (prev) prev.classList.add('active');
    e.preventDefault();
  } else if (e.key === 'Enter') {
    const sel = list.querySelector('.autocomplete-item.active') || items[0];
    if (sel) sel.click();
    e.preventDefault();
  }
});

async function buscarColonias(q) {
  const data = await apiFetch({ action: 'buscar_colonias', q });
  const list = document.getElementById('autocompleteList');
  list.innerHTML = '';
  if (!data.length) { list.classList.remove('show'); return; }
  data.forEach(c => {
    const item = document.createElement('div');
    item.className = 'autocomplete-item';
    item.innerHTML = `💧 ${c.nombre} <span class="sector">${c.sector||''}</span>`;
    item.addEventListener('click', () => seleccionarColonia(c));
    list.appendChild(item);
  });
  list.classList.add('show');
}

async function seleccionarColonia(c) {
  coloniaSeleccionada = c;
  document.getElementById('searchColonia').value = c.nombre;
  document.getElementById('autocompleteList').classList.remove('show');

  const data = await apiFetch({ action: 'colonia_detalle', id: c.id });
  mostrarColoniaInfo(data);
  mostrarTab('inicio');
}

function mostrarColoniaInfo(data) {
  coloniaSeleccionada = data;
  document.getElementById('bienvenidaMsg').style.display = 'none';
  document.getElementById('coloniaInfo').style.display = 'block';
  document.getElementById('coloniaNombre').textContent = data.nombre;
  document.getElementById('coloniaSector').textContent = data.sector ? '📍 ' + data.sector : '';

  // Cumplimiento
  const pct = data.cumplimiento;
  if (pct >= 0) {
    document.getElementById('cumplimientoPct').textContent = pct + '%';
    const bar = document.getElementById('cumplimientoBar');
    bar.style.width = pct + '%';
    bar.style.background = pct >= 70 ? 'var(--verde)' : pct >= 40 ? 'var(--amarillo)' : 'var(--rojo)';
  }

  // Hora probable
  if (data.hora_probable) {
    document.getElementById('horaProbable').style.display = 'flex';
    document.getElementById('horaProbableTexto').textContent = `Hora probable de regreso del agua hoy: ${data.hora_probable} hrs`;
  }

  // Calendario tandeos
  renderCalendario(data.tandeos || []);

  // Histórico si estamos en ese tab
  if (tabActual === 'historico') cargarHistorico(data.id);
}

// ============================================================
// CALENDARIO SEMANAL
// ============================================================
const DIAS = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];

function renderCalendario(tandeos) {
  const grid = document.getElementById('calendarioTandeos');
  const hoy = new Date().getDay(); // 0=Dom
  grid.innerHTML = '';
  for (let d = 0; d < 7; d++) {
    const tandeosDia = tandeos.filter(t => parseInt(t.dia_semana) === d);
    const cell = document.createElement('div');
    cell.className = 'dia-cell' + (tandeosDia.length ? ' tiene-tandeo' : '') + (d === hoy ? ' hoy' : '');
    cell.innerHTML = `<div class="dia-nombre">${DIAS[d]}</div><div class="dia-icon">${tandeosDia.length ? '💧' : ''}</div>`;
    if (tandeosDia.length) {
      tandeosDia.forEach(t => {
        const hi = t.hora_inicio.substring(0,5);
        const hf = t.hora_fin.substring(0,5);
        const span = document.createElement('div');
        span.className = 'dia-horario';
        span.textContent = hi + '-' + hf;
        cell.appendChild(span);
      });
    }
    grid.appendChild(cell);
  }
}

// ============================================================
// REPORTAR ESTADO
// ============================================================
async function registrarEstado(estado, btn) {
  if (!coloniaSeleccionada) { toast('Primero selecciona una colonia', 'error'); return; }

  // Obtener GPS si está disponible
  let lat = 0, lng = 0;
  if (navigator.geolocation) {
    await new Promise(res => navigator.geolocation.getCurrentPosition(p => {
      lat = p.coords.latitude; lng = p.coords.longitude; res();
    }, () => res(), { timeout: 3000 }));
  }

  document.querySelectorAll('.estado-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');

  const data = await apiFetch({ action: 'registrar_reporte', colonia_id: coloniaSeleccionada.id, estado, lat, lng }, 'POST');
  if (data.success) {
    const emojis = { sin_agua: '🔴', baja_presion: '🟡', normal: '🟢' };
    const labels = { sin_agua: 'Sin agua', baja_presion: 'Baja presión', normal: 'Presión normal' };
    toast(emojis[estado] + ' Reporte enviado: ' + labels[estado], 'success');
  } else {
    toast(data.error || 'Error al enviar reporte', 'error');
  }
}

// ============================================================
// MAPA INTERACTIVO
// ============================================================
let mapa = null;
let mapaMarkers = [];

function initMapa() {
  if (mapa) return;
  mapa = L.map('mapa').setView([23.7369, -99.1430], 13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap',
    maxZoom: 18
  }).addTo(mapa);
}

async function cargarMapa() {
  initMapa();
  const data = await apiFetch({ action: 'mapa_estado' });
  mapaMarkers.forEach(m => m.remove());
  mapaMarkers = [];

  const colores = { sin_agua: '#C62828', baja_presion: '#F9A825', normal: '#2E7D32', null: '#90A4AE' };
  const labels = { sin_agua: '🔴 Sin agua', baja_presion: '🟡 Baja presión', normal: '🟢 Normal' };

  data.forEach(col => {
    if (!col.lat || !col.lng) return;
    const color = colores[col.estado_actual] || colores['null'];
    const icon = L.divIcon({
      html: `<div style="background:${color};width:16px;height:16px;border-radius:50%;border:2.5px solid white;box-shadow:0 2px 6px rgba(0,0,0,.3);"></div>`,
      iconSize: [16, 16], className: ''
    });
    const marker = L.marker([parseFloat(col.lat), parseFloat(col.lng)], { icon });
    marker.bindPopup(`
      <b>${col.nombre}</b><br>
      Estado: ${labels[col.estado_actual] || '⚪ Sin reportes'}<br>
      Reportes (2h): ${col.total_reportes || 0}
      <br><small><a href="#" onclick="seleccionarColoniaMapa(${col.id},'${col.nombre}',${col.lat},${col.lng})">Ver detalles</a></small>
    `);
    marker.addTo(mapa);
    mapaMarkers.push(marker);
  });
}

function seleccionarColoniaMapa(id, nombre, lat, lng) {
  seleccionarColonia({ id, nombre });
  mostrarTab('inicio');
}

// ============================================================
// FUGAS
// ============================================================
async function cargarFugas() {
  const data = await apiFetch({ action: 'lista_fugas', estado: 'abierto' });
  const cont = document.getElementById('listaFugas');
  if (!data.length) {
    cont.innerHTML = '<div class="empty"><div class="icon">✅</div><p>No hay fugas reportadas actualmente.</p></div>';
    return;
  }
  cont.innerHTML = data.map(f => `
    <div class="fuga-card">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
        <div class="fuga-folio">${f.folio}</div>
        <span class="estado-tag tag-${f.estado}">${f.estado === 'abierto' ? 'Abierto' : f.estado === 'en_proceso' ? 'En proceso' : 'Resuelto'}</span>
      </div>
      <div class="fuga-meta">📍 ${f.colonia_nombre || 'Sin colonia'} · ${formatFecha(f.created_at)}</div>
      <div class="fuga-desc">${f.descripcion || 'Sin descripción'}</div>
      <div class="fuga-actions">
        <span class="badge-firmas">✍️ ${f.firmas} vecinos</span>
        <button class="btn-firmar" onclick="firmarFuga(${f.id}, this)">✍️ Firmar</button>
        <a class="btn-pdf" href="generar_pdf.php?id=${f.id}" target="_blank">📄 PDF</a>
      </div>
    </div>
  `).join('');
}

async function firmarFuga(id, btn) {
  <?php if (!$usuario): ?>
    toast('Debes iniciar sesión para firmar', 'error');
    abrirModal('modalAuth');
    return;
  <?php endif; ?>
  const data = await apiFetch({ action: 'firmar_fuga', fuga_id: id }, 'POST');
  if (data.success) {
    toast('✅ Firma registrada. Ahora ' + data.firmas + ' vecinos', 'success');
    btn.disabled = true; btn.textContent = '✅ Firmado';
    const badge = btn.previousElementSibling;
    if (badge) badge.textContent = '✍️ ' + data.firmas + ' vecinos';
  } else {
    toast(data.error || 'Error', 'error');
  }
}

// GPS y envío de fuga
let fugaLat = 0, fugaLng = 0;

async function obtenerGPSYEnviar() {
  const gpsInfo = document.getElementById('fugaGPSInfo');
  gpsInfo.style.display = 'block';
  document.getElementById('fugaGPSTexto').textContent = 'Obteniendo ubicación...';

  if (navigator.geolocation) {
    await new Promise(res => navigator.geolocation.getCurrentPosition(p => {
      fugaLat = p.coords.latitude;
      fugaLng = p.coords.longitude;
      document.getElementById('fugaGPSTexto').textContent = `Lat: ${fugaLat.toFixed(5)}, Lng: ${fugaLng.toFixed(5)}`;
      res();
    }, () => {
      document.getElementById('fugaGPSTexto').textContent = 'GPS no disponible (opcional)';
      res();
    }, { timeout: 5000 }));
  }

  const fd = new FormData();
  fd.append('action', 'reportar_fuga');
  fd.append('colonia_id', document.getElementById('fugaColonia').value);
  fd.append('descripcion', document.getElementById('fugaDesc').value);
  fd.append('lat', fugaLat);
  fd.append('lng', fugaLng);
  const fotoInput = document.getElementById('fugaFoto');
  if (fotoInput.files[0]) fd.append('foto', fotoInput.files[0]);

  const data = await apiFetch({}, 'POST', fd);
  if (data.success) {
    cerrarModal('modalFuga');
    toast('🚨 Fuga reportada! Folio: ' + data.folio, 'success');
    document.getElementById('fugaDesc').value = '';
    document.getElementById('fugaFoto').value = '';
    gpsInfo.style.display = 'none';
    cargarFugas();
  } else {
    toast(data.error || 'Error al reportar', 'error');
  }
}

// ============================================================
// DIRECTORIO
// ============================================================
const catIconos = { pipas: '🚚', purificadoras: '💧', plomeros: '🔧' };

async function cargarDirectorio(cat) {
  document.querySelectorAll('.cat-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.cat === cat);
  });
  const data = await apiFetch({ action: 'directorio', categoria: cat });
  const cont = document.getElementById('listaDirectorio');
  if (!data.length) {
    cont.innerHTML = '<div class="empty"><div class="icon">📭</div><p>Sin resultados</p></div>';
    return;
  }
  cont.innerHTML = data.map(s => `
    <div class="servicio-card">
      <div class="servicio-icon">${catIconos[s.categoria] || '📋'}</div>
      <div class="servicio-info">
        <div class="servicio-nombre">${s.nombre}</div>
        <div class="servicio-desc">${s.descripcion || ''}</div>
        <div class="servicio-btns">
          ${s.telefono ? `<a class="btn-llamar" href="tel:${s.telefono}">📞 Llamar</a>` : ''}
          ${s.whatsapp ? `<a class="btn-whatsapp" href="https://wa.me/52${s.whatsapp}" target="_blank">💬 WhatsApp</a>` : ''}
        </div>
      </div>
    </div>
  `).join('');
}

// ============================================================
// HISTÓRICO
// ============================================================
let graficaChart = null;

async function cargarHistorico(coloniaId) {
  if (!coloniaId) return;
  const data = await apiFetch({ action: 'historico_colonia', id: coloniaId });
  const cont = document.getElementById('historicoColonia');

  let html = '';
  if (data.hora_probable) {
    html += `<div class="hora-probable" style="margin-bottom:12px;">⏰ Hora probable de llegada hoy: <strong>${data.hora_probable} hrs</strong></div>`;
  }
  const pct = data.cumplimiento;
  if (pct >= 0) {
    html += `<div class="cumplimiento-bar" style="margin-bottom:12px;">
      <div class="cumplimiento-label"><span>Cumplimiento semanal</span><span>${pct}%</span></div>
      <div class="bar-track"><div class="bar-fill" style="width:${pct}%;background:${pct>=70?'var(--verde)':pct>=40?'var(--amarillo)':'var(--rojo)'}"></div></div>
    </div>`;
  }
  cont.innerHTML = html || '<p style="color:#90A4AE;font-size:.9rem;">Sin datos históricos aún.</p>';

  // Gráfica 30 días
  const grafica30 = document.getElementById('grafica30Container');
  if (data.historico && data.historico.length) {
    grafica30.style.display = 'block';
    renderGrafica30(data.historico);
  } else {
    grafica30.style.display = 'none';
  }
}

function renderGrafica30(historico) {
  const canvas = document.getElementById('grafica30');
  if (graficaChart) graficaChart.destroy();

  // Agrupar por fecha, contar reportes "normal"
  const fechas = {};
  historico.forEach(r => {
    if (!fechas[r.fecha]) fechas[r.fecha] = { normal: 0, sin_agua: 0, baja_presion: 0 };
    fechas[r.fecha][r.estado] = (fechas[r.fecha][r.estado] || 0) + parseInt(r.total);
  });
  const labels = Object.keys(fechas).slice(-20).map(d => d.substring(5)); // MM-DD
  const normales = labels.map(l => {
    const k = Object.keys(fechas).find(k => k.endsWith(l.replace('-', '-')));
    return fechas[k]?.normal || 0;
  });
  const sinAgua = labels.map((l, i) => {
    const k = Object.keys(fechas).slice(-20)[i];
    return fechas[k]?.sin_agua || 0;
  });

  graficaChart = new Chart(canvas, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        { label: 'Normal 🟢', data: normales, backgroundColor: '#A5D6A7', borderRadius: 4 },
        { label: 'Sin agua 🔴', data: sinAgua, backgroundColor: '#EF9A9A', borderRadius: 4 }
      ]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom', labels: { font: { family: 'Nunito', size: 11 } } } },
      scales: {
        x: { ticks: { font: { size: 10 } } },
        y: { beginAtZero: true, ticks: { stepSize: 1 } }
      }
    }
  });
}

// ============================================================
// PERFIL / KARMA
// ============================================================
async function cargarPerfil() {
  <?php if ($usuario): ?>
  // Barra karma
  const karma = <?= $usuario['karma'] ?>;
  const maxKarma = { nuevo: 50, basico: 200, confiable: 500, experto: 1000 };
  const nivel = '<?= $usuario['nivel_reputacion'] ?>';
  const max = maxKarma[nivel] || 500;
  document.getElementById('karmaFill').style.width = Math.min((karma / max) * 100, 100) + '%';

  // Favoritos
  const favs = await apiFetch({ action: 'mis_favoritos' });
  const cont = document.getElementById('listaFavoritos');
  if (!favs.length) {
    cont.innerHTML = '<div class="empty"><div class="icon">⭐</div><p>No tienes colonias favoritas aún.<br>Búscalas y toca el ⭐ para agregarlas.</p></div>';
  } else {
    cont.innerHTML = favs.map(f => `
      <div style="display:flex;align-items:center;gap:10px;background:white;padding:10px 14px;border-radius:var(--radio-sm);margin-bottom:6px;box-shadow:0 1px 4px rgba(0,0,0,.07);">
        <span style="font-size:1.2rem;">💧</span>
        <div style="flex:1;font-weight:600;">${f.nombre}<br><small style="color:#78909C;font-weight:400;">${f.sector||''}</small></div>
        <button onclick="toggleFavorito(${f.id}, this)" style="background:none;border:none;font-size:1.2rem;cursor:pointer;">⭐</button>
      </div>
    `).join('');
  }
  <?php endif; ?>
}

async function toggleFavorito(coloniaId, btn) {
  <?php if (!$usuario): ?>
    toast('Debes iniciar sesión', 'error');
    abrirModal('modalAuth');
    return;
  <?php endif; ?>
  const data = await apiFetch({ action: 'toggle_favorito', colonia_id: coloniaId }, 'POST');
  if (data.action === 'added') {
    toast('⭐ Agregado a favoritos', 'success');
    if (btn) btn.textContent = '⭐';
  } else {
    toast('Eliminado de favoritos', '');
    if (btn) btn.closest('[style*="background:white"]')?.remove();
  }
}

// ============================================================
// AUTH
// ============================================================
function switchAuth(mode) {
  document.getElementById('formLogin').style.display = mode === 'login' ? 'block' : 'none';
  document.getElementById('formRegistro').style.display = mode === 'registro' ? 'block' : 'none';
  document.getElementById('tabLoginBtn').classList.toggle('active', mode === 'login');
  document.getElementById('tabRegBtn').classList.toggle('active', mode === 'registro');
}

async function doLogin() {
  const id = document.getElementById('loginId').value.trim();
  const pass = document.getElementById('loginPass').value;
  if (!id || !pass) { toast('Completa todos los campos', 'error'); return; }
  const data = await apiFetch({ action: 'login', identificador: id, password: pass }, 'POST');
  if (data.success) {
    toast('✅ Bienvenido/a, ' + data.usuario.nombre, 'success');
    setTimeout(() => location.reload(), 1000);
  } else {
    toast(data.error || 'Error de acceso', 'error');
  }
}

async function doRegistro() {
  const nombre = document.getElementById('regNombre').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const tel = document.getElementById('regTel').value.trim();
  const pass = document.getElementById('regPass').value;
  if (!nombre || (!email && !tel) || !pass) { toast('Completa los campos requeridos', 'error'); return; }
  const data = await apiFetch({ action: 'registro', nombre, email, telefono: tel, password: pass }, 'POST');
  if (data.success) {
    toast('✅ Cuenta creada. ¡Bienvenido/a!', 'success');
    setTimeout(() => location.reload(), 1000);
  } else {
    toast(data.error || 'Error al registrarse', 'error');
  }
}

async function cerrarSesion() {
  await apiFetch({ action: 'logout' }, 'POST');
  location.reload();
}

// ============================================================
// NOTIFICACIONES
// ============================================================
async function abrirNotificaciones() {
  abrirModal('modalNotif');
  <?php if ($usuario): ?>
  const data = await apiFetch({ action: 'notificaciones' });
  const cont = document.getElementById('listaNotif');
  if (!data.length) {
    cont.innerHTML = '<div class="empty"><div class="icon">🔔</div><p>No hay notificaciones</p></div>';
  } else {
    cont.innerHTML = data.map(n => `
      <div class="notif-item ${n.leida ? '' : 'no-leida'}">
        <div class="notif-icon">${n.leida ? '🔔' : '🔔'}</div>
        <div>
          <div class="notif-texto">${n.mensaje}</div>
          <div class="notif-hora">${formatFecha(n.created_at)}</div>
        </div>
      </div>
    `).join('');
    await apiFetch({ action: 'marcar_leida' }, 'POST');
    document.getElementById('badgeNotif').style.display = 'none';
  }
  <?php else: ?>
  document.getElementById('listaNotif').innerHTML = '<div class="empty"><p>Inicia sesión para ver notificaciones</p></div>';
  <?php endif; ?>
}

async function verificarNotificaciones() {
  <?php if ($usuario): ?>
  const data = await apiFetch({ action: 'notificaciones' });
  const noLeidas = data.filter(n => !n.leida).length;
  const badge = document.getElementById('badgeNotif');
  if (noLeidas > 0) {
    badge.style.display = 'flex';
    badge.textContent = noLeidas;
  } else {
    badge.style.display = 'none';
  }
  <?php endif; ?>
}

// ============================================================
// CSV ADMIN
// ============================================================
async function subirCSV() {
  const file = document.getElementById('csvFile').files[0];
  if (!file) { toast('Selecciona un archivo CSV', 'error'); return; }
  const fd = new FormData();
  fd.append('action', 'admin_csv');
  fd.append('csv', file);
  const data = await apiFetch({}, 'POST', fd);
  const res = document.getElementById('csvResultado');
  if (data.success) {
    res.innerHTML = `<span style="color:var(--verde)">✅ ${data.insertados} registros cargados.</span>`;
    if (data.errores?.length) {
      res.innerHTML += '<br>' + data.errores.map(e => `⚠️ ${e}`).join('<br>');
    }
  } else {
    res.innerHTML = `<span style="color:var(--rojo)">❌ ${data.error}</span>`;
  }
}

// ============================================================
// UTILIDADES
// ============================================================
function formatFecha(str) {
  const d = new Date(str);
  const hoy = new Date();
  const diff = (hoy - d) / 60000;
  if (diff < 60) return 'Hace ' + Math.round(diff) + ' min';
  if (diff < 1440) return 'Hace ' + Math.round(diff/60) + ' hrs';
  return d.toLocaleDateString('es-MX', { day:'numeric', month:'short' });
}

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  verificarNotificaciones();
  setInterval(verificarNotificaciones, 60000); // cada minuto
});

// Cerrar autocomplete al tocar fuera
document.addEventListener('click', e => {
  if (!e.target.closest('.search-wrap')) {
    document.getElementById('autocompleteList').classList.remove('show');
  }
});
</script>
</body>
</html>
