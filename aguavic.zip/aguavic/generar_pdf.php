<?php
// ============================================================
//  AguaVic - Generador de PDF para Reporte de Fuga
//  Archivo: generar_pdf.php
//  Requiere: composer require tecnickcom/tcpdf
//  O usar la versión HTML para imprimir (más fácil con XAMPP)
// ============================================================
require_once 'config.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { die('ID de fuga requerido'); }

$db = getDB();
$stmt = $db->prepare("SELECT f.*, c.nombre as colonia_nombre FROM fugas f LEFT JOIN colonias c ON c.id = f.colonia_id WHERE f.id = ?");
$stmt->execute([$id]);
$fuga = $stmt->fetch();
if (!$fuga) { die('Fuga no encontrada'); }

$stmt2 = $db->prepare("SELECT nombre_firmante, created_at FROM firmas_fugas WHERE fuga_id = ? ORDER BY created_at");
$stmt2->execute([$id]);
$firmantes = $stmt2->fetchAll();

$fotoURL = $fuga['foto_path'] ? UPLOAD_URL . $fuga['foto_path'] : null;
$fotoPath = $fuga['foto_path'] ? UPLOAD_DIR . $fuga['foto_path'] : null;

$fecha = date('d/m/Y H:i', strtotime($fuga['created_at']));
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reporte Oficial - <?= htmlspecialchars($fuga['folio']) ?></title>
<style>
  @page { margin: 2cm; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Times New Roman', serif; font-size: 11pt; color: #111; background: white; }
  .header { text-align: center; border-bottom: 3px solid #1565C0; padding-bottom: 12px; margin-bottom: 20px; }
  .header h1 { font-size: 18pt; color: #1565C0; letter-spacing: 2px; }
  .header h2 { font-size: 13pt; color: #333; margin-top: 4px; }
  .folio-badge { background: #1565C0; color: white; display: inline-block; padding: 6px 20px; border-radius: 4px; font-size: 14pt; font-weight: bold; margin: 10px 0; letter-spacing: 3px; }
  .seccion { margin-bottom: 18px; }
  .seccion h3 { font-size: 11pt; color: #1565C0; border-bottom: 1px solid #90CAF9; padding-bottom: 4px; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
  .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .campo { margin-bottom: 8px; }
  .campo label { font-size: 9pt; color: #666; display: block; }
  .campo span { font-size: 11pt; font-weight: bold; }
  .foto { max-width: 100%; max-height: 250px; border: 1px solid #ddd; margin-top: 8px; }
  .mapa-link { font-size: 9pt; color: #1565C0; word-break: break-all; }
  table.firmas { width: 100%; border-collapse: collapse; font-size: 10pt; }
  table.firmas th { background: #E3F2FD; padding: 6px 8px; text-align: left; border: 1px solid #ddd; }
  table.firmas td { padding: 5px 8px; border: 1px solid #ddd; vertical-align: top; }
  table.firmas tr:nth-child(even) td { background: #F9F9F9; }
  .firma-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-top: 8px; }
  .firma-item { border: 1px solid #ccc; padding: 6px 10px; border-radius: 4px; font-size: 10pt; }
  .firma-item .num { font-size: 8pt; color: #999; }
  .estado-badge { display: inline-block; padding: 3px 12px; border-radius: 20px; font-size: 10pt; font-weight: bold; }
  .estado-abierto { background: #FFCCCC; color: #B00020; }
  .estado-proceso { background: #FFF3CD; color: #856404; }
  .estado-resuelto { background: #D4EDDA; color: #155724; }
  .footer { margin-top: 30px; border-top: 1px solid #ccc; padding-top: 12px; font-size: 9pt; color: #666; text-align: center; }
  .no-print { margin-top: 20px; text-align: center; }
  .btn-print { background: #1565C0; color: white; border: none; padding: 12px 30px; font-size: 12pt; cursor: pointer; border-radius: 6px; }
  @media print { .no-print { display: none; } }
</style>
</head>
<body>

<div class="header">
  <h1>🌊 AguaVic</h1>
  <h2>Monitor Comunitario de Tandeos - Ciudad Victoria, Tamaulipas</h2>
  <p style="font-size:10pt;color:#555;margin-top:4px;">Reporte Ciudadano Oficial de Fuga de Agua</p>
  <div class="folio-badge"><?= htmlspecialchars($fuga['folio']) ?></div>
</div>

<div class="seccion">
  <h3>📋 Datos del Reporte</h3>
  <div class="grid2">
    <div class="campo">
      <label>Número de Folio</label>
      <span><?= htmlspecialchars($fuga['folio']) ?></span>
    </div>
    <div class="campo">
      <label>Estado Actual</label>
      <span class="estado-badge estado-<?= $fuga['estado'] ?>"><?= ucfirst(str_replace('_', ' ', $fuga['estado'])) ?></span>
    </div>
    <div class="campo">
      <label>Fecha y Hora del Reporte</label>
      <span><?= $fecha ?></span>
    </div>
    <div class="campo">
      <label>Colonia / Fraccionamiento</label>
      <span><?= htmlspecialchars($fuga['colonia_nombre'] ?? 'No especificada') ?></span>
    </div>
    <div class="campo">
      <label>Total de Vecinos Afectados (Firmas)</label>
      <span style="font-size:14pt;color:#1565C0;"><?= count($firmantes) ?> vecinos</span>
    </div>
  </div>
</div>

<div class="seccion">
  <h3>📍 Ubicación GPS</h3>
  <?php if ($fuga['lat'] && $fuga['lng']): ?>
    <div class="campo">
      <label>Coordenadas</label>
      <span><?= $fuga['lat'] ?>, <?= $fuga['lng'] ?></span>
    </div>
    <div class="campo">
      <label>Ver en Google Maps</label><br>
      <a class="mapa-link" href="https://www.google.com/maps?q=<?= $fuga['lat'] ?>,<?= $fuga['lng'] ?>" target="_blank">
        https://www.google.com/maps?q=<?= $fuga['lat'] ?>,<?= $fuga['lng'] ?>
      </a>
    </div>
  <?php else: ?>
    <p style="color:#999;font-style:italic;">Coordenadas no disponibles</p>
  <?php endif; ?>
</div>

<div class="seccion">
  <h3>📝 Descripción del Problema</h3>
  <p style="padding:10px;background:#F5F5F5;border-left:4px solid #1565C0;line-height:1.6;">
    <?= nl2br(htmlspecialchars($fuga['descripcion'] ?: 'Sin descripción proporcionada.')) ?>
  </p>
</div>

<?php if ($fotoPath && file_exists($fotoPath)): ?>
<div class="seccion">
  <h3>📸 Fotografía Adjunta</h3>
  <img src="<?= htmlspecialchars($fotoURL) ?>" class="foto" alt="Foto de la fuga">
</div>
<?php endif; ?>

<div class="seccion">
  <h3>✍️ Firmas Ciudadanas (<?= count($firmantes) ?> vecinos)</h3>
  <?php if ($firmantes): ?>
  <div class="firma-grid">
    <?php foreach ($firmantes as $i => $f): ?>
    <div class="firma-item">
      <div class="num">#<?= $i + 1 ?> — <?= date('d/m/Y', strtotime($f['created_at'])) ?></div>
      <strong><?= htmlspecialchars($f['nombre_firmante'] ?: 'Ciudadano Anónimo') ?></strong>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
    <p style="color:#999;font-style:italic;">Sin firmas registradas</p>
  <?php endif; ?>
</div>

<div class="footer">
  <p>Este documento fue generado automáticamente por el sistema <strong>AguaVic</strong> el <?= date('d/m/Y \a \l\a\s H:i') ?> hrs.</p>
  <p style="margin-top:4px;">Este reporte puede ser presentado ante las oficinas de la Comisión Municipal de Agua de Ciudad Victoria.</p>
  <p style="margin-top:4px;">Folio: <strong><?= htmlspecialchars($fuga['folio']) ?></strong> | Firmantes: <strong><?= count($firmantes) ?></strong></p>
</div>

<div class="no-print">
  <button class="btn-print" onclick="window.print()">🖨️ Imprimir / Guardar PDF</button>
  <button style="margin-left:12px;background:#eee;border:1px solid #ccc;padding:12px 20px;border-radius:6px;cursor:pointer;" onclick="window.close()">✕ Cerrar</button>
</div>

</body>
</html>
