-- ============================================================
--  AguaVic - Base de Datos Completa
--  Compatible con MySQL / MariaDB (XAMPP)
--  Ejecutar en phpMyAdmin o terminal MySQL
-- ============================================================

CREATE DATABASE IF NOT EXISTS aguavic CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE aguavic;

-- ============================================================
-- TABLA: colonias
-- ============================================================
CREATE TABLE colonias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    sector VARCHAR(100),
    lat DECIMAL(10,7),
    lng DECIMAL(10,7),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLA: tandeos (horarios oficiales por colonia)
-- ============================================================
CREATE TABLE tandeos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    colonia_id INT NOT NULL,
    dia_semana TINYINT NOT NULL COMMENT '0=Dom,1=Lun,...,6=Sab',
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    activo TINYINT(1) DEFAULT 1,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (colonia_id) REFERENCES colonias(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLA: usuarios
-- ============================================================
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    email VARCHAR(150) UNIQUE,
    telefono VARCHAR(20) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    karma INT DEFAULT 100,
    nivel_reputacion ENUM('nuevo','basico','confiable','experto') DEFAULT 'nuevo',
    verified TINYINT(1) DEFAULT 0,
    token_verificacion VARCHAR(64),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLA: favoritos
-- ============================================================
CREATE TABLE favoritos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    colonia_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_fav (usuario_id, colonia_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (colonia_id) REFERENCES colonias(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLA: reportes_estado (Sin agua / Baja presión / Normal)
-- ============================================================
CREATE TABLE reportes_estado (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    colonia_id INT NOT NULL,
    estado ENUM('sin_agua','baja_presion','normal') NOT NULL,
    lat DECIMAL(10,7),
    lng DECIMAL(10,7),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    FOREIGN KEY (colonia_id) REFERENCES colonias(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLA: fugas
-- ============================================================
CREATE TABLE fugas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    folio VARCHAR(20) UNIQUE NOT NULL,
    usuario_id INT,
    colonia_id INT,
    descripcion TEXT,
    foto_path VARCHAR(255),
    lat DECIMAL(10,7),
    lng DECIMAL(10,7),
    estado ENUM('abierto','en_proceso','resuelto') DEFAULT 'abierto',
    firmas INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    FOREIGN KEY (colonia_id) REFERENCES colonias(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- TABLA: firmas_fugas (vecinos que se suman a una fuga)
-- ============================================================
CREATE TABLE firmas_fugas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fuga_id INT NOT NULL,
    usuario_id INT NOT NULL,
    nombre_firmante VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_firma (fuga_id, usuario_id),
    FOREIGN KEY (fuga_id) REFERENCES fugas(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLA: directorio_servicios
-- ============================================================
CREATE TABLE directorio_servicios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    categoria ENUM('pipas','purificadoras','plomeros') NOT NULL,
    telefono VARCHAR(20),
    whatsapp VARCHAR(20),
    descripcion VARCHAR(255),
    activo TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- ============================================================
-- TABLA: notificaciones
-- ============================================================
CREATE TABLE notificaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    mensaje TEXT NOT NULL,
    leida TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- DATOS DE EJEMPLO - Colonias de Ciudad Victoria
-- ============================================================
INSERT INTO colonias (nombre, sector, lat, lng) VALUES
('Centro Histórico', 'Centro', 23.7369, -99.1430),
('Colonia Libertad', 'Norte', 23.7520, -99.1380),
('Fraccionamiento Las Flores', 'Sur', 23.7200, -99.1500),
('Colonia Guadalupe', 'Oriente', 23.7400, -99.1250),
('Colonia Morelos', 'Poniente', 23.7350, -99.1600),
('Fraccionamiento Los Arcos', 'Norte', 23.7600, -99.1420),
('Colonia Revolución', 'Sur', 23.7150, -99.1350),
('Fraccionamiento Valle Alto', 'Sur', 23.7100, -99.1550),
('Colonia Industrial', 'Oriente', 23.7450, -99.1180),
('Colonia Roma', 'Centro', 23.7390, -99.1480),
('Fraccionamiento Jardines', 'Norte', 23.7650, -99.1300),
('Colonia Hidalgo', 'Poniente', 23.7280, -99.1650),
('Colonia Deportiva', 'Centro', 23.7420, -99.1400),
('Fraccionamiento Rincón del Valle', 'Sur', 23.7050, -99.1480),
('Colonia Unión', 'Norte', 23.7580, -99.1460);

-- ============================================================
-- DATOS DE EJEMPLO - Tandeos
-- ============================================================
INSERT INTO tandeos (colonia_id, dia_semana, hora_inicio, hora_fin) VALUES
(1, 1, '06:00:00', '10:00:00'), (1, 4, '06:00:00', '10:00:00'),
(2, 2, '07:00:00', '11:00:00'), (2, 5, '07:00:00', '11:00:00'),
(3, 1, '08:00:00', '12:00:00'), (3, 3, '08:00:00', '12:00:00'),
(4, 2, '06:00:00', '09:00:00'), (4, 6, '06:00:00', '09:00:00'),
(5, 3, '07:00:00', '10:00:00'), (5, 0, '07:00:00', '10:00:00'),
(6, 1, '05:00:00', '08:00:00'), (6, 4, '05:00:00', '08:00:00'),
(7, 2, '08:00:00', '12:00:00'), (7, 5, '08:00:00', '12:00:00'),
(8, 3, '06:00:00', '10:00:00'), (8, 6, '06:00:00', '10:00:00'),
(9, 1, '07:00:00', '11:00:00'), (9, 3, '07:00:00', '11:00:00'),
(10, 2, '06:00:00', '09:00:00'), (10, 5, '06:00:00', '09:00:00');

-- ============================================================
-- DATOS DE EJEMPLO - Directorio
-- ============================================================
INSERT INTO directorio_servicios (nombre, categoria, telefono, whatsapp, descripcion) VALUES
('Pipas Agua Fresca', 'pipas', '8341234567', '8341234567', 'Servicio de pipas 24hrs'),
('Pipas El Manantial', 'pipas', '8349876543', '8349876543', 'Pipas de 5,000 a 20,000 lts'),
('Purificadora AquaPura', 'purificadoras', '8341112233', NULL, 'Garrafones y agua purificada'),
('Purificadora El Cristal', 'purificadoras', '8344455667', '8344455667', 'Entrega a domicilio'),
('Plomero Don Ramón', 'plomeros', '8341231234', '8341231234', 'Reparaciones urgentes 24hrs'),
('Plomería Martínez', 'plomeros', '8347896543', NULL, 'Instalaciones y fugas'),
('Pipas Don Chuy', 'pipas', '8343332211', '8343332211', 'Pipas económicas'),
('Plomero Profesional Vega', 'plomeros', '8348881122', '8348881122', 'Detección de fugas con equipo');

-- ============================================================
-- USUARIO ADMIN DE PRUEBA (password: admin123)
-- ============================================================
INSERT INTO usuarios (nombre, email, password_hash, karma, nivel_reputacion, verified) VALUES
('Administrador', 'admin@aguavic.mx', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 500, 'experto', 1);
