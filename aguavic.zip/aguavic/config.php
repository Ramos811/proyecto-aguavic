<?php
// ============================================================
//  AguaVic - Configuración de Base de Datos
//  Archivo: config.php
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Cambia si tienes otro usuario en XAMPP
define('DB_PASS', '');            // Cambia si tienes contraseña
define('DB_NAME', 'aguavic');
define('DB_CHARSET', 'utf8mb4');

define('BASE_URL', 'http://localhost/aguavic/');
define('UPLOAD_DIR', __DIR__ . '/uploads/fugas/');
define('UPLOAD_URL', BASE_URL . 'uploads/fugas/');

// Zona horaria
date_default_timezone_set('America/Monterrey');

// Conexión PDO singleton
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'Error de conexión a BD: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// Respuesta JSON
function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Iniciar sesión segura
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

// Usuario actual (null si no logueado)
function usuarioActual(): ?array {
    return $_SESSION['usuario'] ?? null;
}

// Verificar login
function requireLogin(): void {
    if (!usuarioActual()) {
        jsonResponse(['error' => 'No autenticado', 'redirect' => BASE_URL . 'index.php#login'], 401);
    }
}
