<?php
// ============================================================
//  AguaVic - API REST unificada
//  Archivo: api.php
//  Uso: api.php?action=nombre_accion
// ============================================================

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {

    // ----------------------------------------------------------
    // COLONIAS
    // ----------------------------------------------------------
    case 'buscar_colonias':
        $q = trim($_GET['q'] ?? '');
        if (strlen($q) < 2) { jsonResponse([]); }
        $db = getDB();
        $stmt = $db->prepare("SELECT id, nombre, sector FROM colonias WHERE nombre LIKE ? LIMIT 10");
        $stmt->execute(["%$q%"]);
        jsonResponse($stmt->fetchAll());
        break;

    case 'colonia_detalle':
        $id = (int)($_GET['id'] ?? 0);
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM colonias WHERE id = ?");
        $stmt->execute([$id]);
        $col = $stmt->fetch();
        if (!$col) { jsonResponse(['error' => 'No encontrada'], 404); }

        // Tandeos
        $stmt2 = $db->prepare("SELECT dia_semana, hora_inicio, hora_fin FROM tandeos WHERE colonia_id = ? AND activo = 1 ORDER BY dia_semana, hora_inicio");
        $stmt2->execute([$id]);
        $col['tandeos'] = $stmt2->fetchAll();

        // Conteo reportes últimas 2h
        $stmt3 = $db->prepare("SELECT estado, COUNT(*) as total FROM reportes_estado WHERE colonia_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 2 HOUR) GROUP BY estado");
        $stmt3->execute([$id]);
        $col['reportes_recientes'] = $stmt3->fetchAll();

        // Cumplimiento semanal
        $col['cumplimiento'] = calcularCumplimiento($db, $id);

        jsonResponse($col);
        break;

    // ----------------------------------------------------------
    // MAPA - Estado actual de colonias
    // ----------------------------------------------------------
    case 'mapa_estado':
        $db = getDB();
        $sql = "SELECT c.id, c.nombre, c.lat, c.lng,
                    (SELECT estado FROM reportes_estado r WHERE r.colonia_id = c.id AND r.created_at >= DATE_SUB(NOW(), INTERVAL 2 HOUR)
                     ORDER BY r.created_at DESC LIMIT 1) as estado_actual,
                    (SELECT COUNT(*) FROM reportes_estado r WHERE r.colonia_id = c.id AND r.created_at >= DATE_SUB(NOW(), INTERVAL 2 HOUR)) as total_reportes
                FROM colonias c";
        $stmt = $db->query($sql);
        jsonResponse($stmt->fetchAll());
        break;

    // ----------------------------------------------------------
    // REPORTES ESTADO
    // ----------------------------------------------------------
    case 'registrar_reporte':
        $colonia_id = (int)($_POST['colonia_id'] ?? 0);
        $estado = $_POST['estado'] ?? '';
        $lat = (float)($_POST['lat'] ?? 0);
        $lng = (float)($_POST['lng'] ?? 0);
        $usuario = usuarioActual();

        if (!in_array($estado, ['sin_agua','baja_presion','normal'])) {
            jsonResponse(['error' => 'Estado inválido'], 400);
        }
        if (!$colonia_id) { jsonResponse(['error' => 'Colonia requerida'], 400); }

        $db = getDB();
        $stmt = $db->prepare("INSERT INTO reportes_estado (usuario_id, colonia_id, estado, lat, lng) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$usuario['id'] ?? null, $colonia_id, $estado, $lat ?: null, $lng ?: null]);

        // Karma: actualizar si hay usuario
        if ($usuario) {
            actualizarKarma($db, $usuario['id'], $colonia_id, $estado);
        }

        // Verificar alertas para favoritos
        if ($estado === 'sin_agua') {
            generarNotificaciones($db, $colonia_id);
        }

        jsonResponse(['success' => true, 'message' => 'Reporte registrado']);
        break;

    // ----------------------------------------------------------
    // FAVORITOS
    // ----------------------------------------------------------
    case 'mis_favoritos':
        requireLogin();
        $u = usuarioActual();
        $db = getDB();
        $stmt = $db->prepare("SELECT c.id, c.nombre, c.sector FROM favoritos f JOIN colonias c ON c.id = f.colonia_id WHERE f.usuario_id = ?");
        $stmt->execute([$u['id']]);
        jsonResponse($stmt->fetchAll());
        break;

    case 'toggle_favorito':
        requireLogin();
        $u = usuarioActual();
        $colonia_id = (int)($_POST['colonia_id'] ?? 0);
        if (!$colonia_id) { jsonResponse(['error' => 'Colonia requerida'], 400); }
        $db = getDB();
        $stmt = $db->prepare("SELECT id FROM favoritos WHERE usuario_id = ? AND colonia_id = ?");
        $stmt->execute([$u['id'], $colonia_id]);
        if ($stmt->fetch()) {
            $db->prepare("DELETE FROM favoritos WHERE usuario_id = ? AND colonia_id = ?")->execute([$u['id'], $colonia_id]);
            jsonResponse(['action' => 'removed']);
        } else {
            $db->prepare("INSERT INTO favoritos (usuario_id, colonia_id) VALUES (?, ?)")->execute([$u['id'], $colonia_id]);
            jsonResponse(['action' => 'added']);
        }
        break;

    // ----------------------------------------------------------
    // FUGAS
    // ----------------------------------------------------------
    case 'reportar_fuga':
        $colonia_id = (int)($_POST['colonia_id'] ?? 0);
        $descripcion = trim($_POST['descripcion'] ?? '');
        $lat = (float)($_POST['lat'] ?? 0);
        $lng = (float)($_POST['lng'] ?? 0);
        $usuario = usuarioActual();

        // Generar folio
        $folio = 'FUG-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));

        // Foto
        $foto_path = null;
        if (!empty($_FILES['foto']['tmp_name'])) {
            $dir = UPLOAD_DIR;
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
            $nombre = $folio . '.' . strtolower($ext);
            if (move_uploaded_file($_FILES['foto']['tmp_name'], $dir . $nombre)) {
                $foto_path = $nombre;
            }
        }

        $db = getDB();
        $stmt = $db->prepare("INSERT INTO fugas (folio, usuario_id, colonia_id, descripcion, foto_path, lat, lng) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$folio, $usuario['id'] ?? null, $colonia_id ?: null, $descripcion, $foto_path, $lat ?: null, $lng ?: null]);
        $fuga_id = $db->lastInsertId();

        // Auto-firma del reportador
        if ($usuario) {
            $db->prepare("INSERT INTO firmas_fugas (fuga_id, usuario_id, nombre_firmante) VALUES (?, ?, ?)")->execute([$fuga_id, $usuario['id'], $usuario['nombre']]);
        }

        jsonResponse(['success' => true, 'folio' => $folio, 'id' => $fuga_id]);
        break;

    case 'lista_fugas':
        $db = getDB();
        $estado = $_GET['estado'] ?? 'abierto';
        $stmt = $db->prepare("SELECT f.*, c.nombre as colonia_nombre FROM fugas f LEFT JOIN colonias c ON c.id = f.colonia_id WHERE f.estado = ? ORDER BY f.created_at DESC LIMIT 50");
        $stmt->execute([$estado]);
        jsonResponse($stmt->fetchAll());
        break;

    case 'firmar_fuga':
        requireLogin();
        $u = usuarioActual();
        $fuga_id = (int)($_POST['fuga_id'] ?? 0);
        $db = getDB();

        // Verificar que no haya firmado ya
        $stmt = $db->prepare("SELECT id FROM firmas_fugas WHERE fuga_id = ? AND usuario_id = ?");
        $stmt->execute([$fuga_id, $u['id']]);
        if ($stmt->fetch()) { jsonResponse(['error' => 'Ya firmaste esta fuga'], 400); }

        $db->prepare("INSERT INTO firmas_fugas (fuga_id, usuario_id, nombre_firmante) VALUES (?, ?, ?)")->execute([$fuga_id, $u['id'], $u['nombre']]);
        $db->prepare("UPDATE fugas SET firmas = firmas + 1 WHERE id = ?")->execute([$fuga_id]);

        $stmt2 = $db->prepare("SELECT firmas FROM fugas WHERE id = ?");
        $stmt2->execute([$fuga_id]);
        $row = $stmt2->fetch();

        jsonResponse(['success' => true, 'firmas' => $row['firmas']]);
        break;

    case 'detalle_fuga':
        $id = (int)($_GET['id'] ?? 0);
        $db = getDB();
        $stmt = $db->prepare("SELECT f.*, c.nombre as colonia_nombre FROM fugas f LEFT JOIN colonias c ON c.id = f.colonia_id WHERE f.id = ?");
        $stmt->execute([$id]);
        $fuga = $stmt->fetch();
        if (!$fuga) { jsonResponse(['error' => 'No encontrada'], 404); }

        // Firmantes
        $stmt2 = $db->prepare("SELECT nombre_firmante, created_at FROM firmas_fugas WHERE fuga_id = ? ORDER BY created_at");
        $stmt2->execute([$id]);
        $fuga['firmantes'] = $stmt2->fetchAll();

        jsonResponse($fuga);
        break;

    // ----------------------------------------------------------
    // DIRECTORIO
    // ----------------------------------------------------------
    case 'directorio':
        $cat = $_GET['categoria'] ?? '';
        $db = getDB();
        if ($cat) {
            $stmt = $db->prepare("SELECT * FROM directorio_servicios WHERE activo = 1 AND categoria = ? ORDER BY nombre");
            $stmt->execute([$cat]);
        } else {
            $stmt = $db->query("SELECT * FROM directorio_servicios WHERE activo = 1 ORDER BY categoria, nombre");
        }
        jsonResponse($stmt->fetchAll());
        break;

    // ----------------------------------------------------------
    // HISTÓRICO y ESTADÍSTICAS
    // ----------------------------------------------------------
    case 'historico_colonia':
        $id = (int)($_GET['id'] ?? 0);
        $db = getDB();
        // Últimos 30 días: horas con reportes de "normal"
        $stmt = $db->prepare("
            SELECT DATE(created_at) as fecha,
                   HOUR(created_at) as hora,
                   estado,
                   COUNT(*) as total
            FROM reportes_estado
            WHERE colonia_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY DATE(created_at), HOUR(created_at), estado
            ORDER BY fecha, hora
        ");
        $stmt->execute([$id]);
        $datos = $stmt->fetchAll();

        // Hora probable de llegada (moda de las horas con "normal" en días similares)
        $diaSemana = date('N'); // 1=Lun ... 7=Dom
        $stmt2 = $db->prepare("
            SELECT HOUR(created_at) as hora, COUNT(*) as frecuencia
            FROM reportes_estado
            WHERE colonia_id = ? AND estado = 'normal' AND DAYOFWEEK(created_at) = DAYOFWEEK(NOW())
            AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)
            GROUP BY HOUR(created_at)
            ORDER BY frecuencia DESC
            LIMIT 1
        ");
        $stmt2->execute([$id]);
        $hora_probable = $stmt2->fetch();

        jsonResponse([
            'historico' => $datos,
            'hora_probable' => $hora_probable ? sprintf('%02d:00', $hora_probable['hora']) : null,
            'cumplimiento' => calcularCumplimiento($db, $id)
        ]);
        break;

    // ----------------------------------------------------------
    // AUTH
    // ----------------------------------------------------------
    case 'registro':
        $nombre = trim($_POST['nombre'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telefono = trim($_POST['telefono'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$nombre || (!$email && !$telefono) || !$password) {
            jsonResponse(['error' => 'Datos incompletos'], 400);
        }
        if (strlen($password) < 6) { jsonResponse(['error' => 'Contraseña muy corta (mín. 6)'], 400); }

        $db = getDB();
        // Verificar duplicado
        if ($email) {
            $stmt = $db->prepare("SELECT id FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) { jsonResponse(['error' => 'Email ya registrado'], 409); }
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);
        $token = bin2hex(random_bytes(32));
        $stmt = $db->prepare("INSERT INTO usuarios (nombre, email, telefono, password_hash, token_verificacion) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nombre, $email ?: null, $telefono ?: null, $hash, $token]);
        $uid = $db->lastInsertId();

        $_SESSION['usuario'] = ['id' => $uid, 'nombre' => $nombre, 'email' => $email, 'karma' => 100, 'nivel_reputacion' => 'nuevo'];
        jsonResponse(['success' => true, 'usuario' => $_SESSION['usuario']]);
        break;

    case 'login':
        $identificador = trim($_POST['identificador'] ?? '');
        $password = $_POST['password'] ?? '';

        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = ? OR telefono = ? LIMIT 1");
        $stmt->execute([$identificador, $identificador]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            jsonResponse(['error' => 'Credenciales incorrectas'], 401);
        }

        $_SESSION['usuario'] = [
            'id' => $user['id'],
            'nombre' => $user['nombre'],
            'email' => $user['email'],
            'karma' => $user['karma'],
            'nivel_reputacion' => $user['nivel_reputacion']
        ];
        jsonResponse(['success' => true, 'usuario' => $_SESSION['usuario']]);
        break;

    case 'logout':
        session_destroy();
        jsonResponse(['success' => true]);
        break;

    case 'sesion_actual':
        $u = usuarioActual();
        jsonResponse($u ? ['logueado' => true, 'usuario' => $u] : ['logueado' => false]);
        break;

    case 'notificaciones':
        requireLogin();
        $u = usuarioActual();
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM notificaciones WHERE usuario_id = ? ORDER BY created_at DESC LIMIT 20");
        $stmt->execute([$u['id']]);
        jsonResponse($stmt->fetchAll());
        break;

    case 'marcar_leida':
        requireLogin();
        $u = usuarioActual();
        $db = getDB();
        $db->prepare("UPDATE notificaciones SET leida = 1 WHERE usuario_id = ?")->execute([$u['id']]);
        jsonResponse(['success' => true]);
        break;

    // ----------------------------------------------------------
    // ADMIN: Carga masiva CSV
    // ----------------------------------------------------------
    case 'admin_csv':
        $usuario = usuarioActual();
        if (!$usuario || $usuario['nivel_reputacion'] !== 'experto') {
            jsonResponse(['error' => 'Sin permisos'], 403);
        }
        if (empty($_FILES['csv']['tmp_name'])) { jsonResponse(['error' => 'Archivo requerido'], 400); }

        $handle = fopen($_FILES['csv']['tmp_name'], 'r');
        $db = getDB();
        $insertados = 0;
        $errores = [];
        $linea = 0;

        while (($row = fgetcsv($handle)) !== false) {
            $linea++;
            if ($linea === 1) continue; // Saltar encabezado
            // Formato CSV: colonia_nombre, dia_semana(0-6), hora_inicio(HH:MM), hora_fin(HH:MM)
            if (count($row) < 4) { $errores[] = "Línea $linea: columnas insuficientes"; continue; }
            [$nombre, $dia, $hi, $hf] = $row;

            $stmt = $db->prepare("SELECT id FROM colonias WHERE nombre LIKE ?");
            $stmt->execute([trim($nombre)]);
            $col = $stmt->fetch();
            if (!$col) { $errores[] = "Línea $linea: colonia '$nombre' no encontrada"; continue; }

            // Desactivar tandeos anteriores de ese día para esa colonia
            $db->prepare("UPDATE tandeos SET activo = 0 WHERE colonia_id = ? AND dia_semana = ?")->execute([$col['id'], (int)$dia]);
            $db->prepare("INSERT INTO tandeos (colonia_id, dia_semana, hora_inicio, hora_fin) VALUES (?, ?, ?, ?)")->execute([$col['id'], (int)$dia, trim($hi), trim($hf)]);
            $insertados++;
        }
        fclose($handle);

        jsonResponse(['success' => true, 'insertados' => $insertados, 'errores' => $errores]);
        break;

    default:
        jsonResponse(['error' => 'Acción no reconocida'], 400);
}

// ----------------------------------------------------------
// FUNCIONES AUXILIARES
// ----------------------------------------------------------

function calcularCumplimiento(PDO $db, int $colonia_id): float {
    // Comparar reportes "normal" dentro de ventanas de tandeo vs total tandeos esta semana
    $stmt = $db->prepare("
        SELECT COUNT(*) as total FROM tandeos
        WHERE colonia_id = ? AND activo = 1
        AND dia_semana = DAYOFWEEK(NOW()) - 1
    ");
    $stmt->execute([$colonia_id]);
    $hayTandeo = $stmt->fetchColumn();
    if (!$hayTandeo) return -1;

    $stmt2 = $db->prepare("
        SELECT COUNT(*) FROM reportes_estado
        WHERE colonia_id = ? AND estado = 'normal'
        AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stmt2->execute([$colonia_id]);
    $normales = (int)$stmt2->fetchColumn();

    $stmt3 = $db->prepare("
        SELECT COUNT(*) FROM reportes_estado
        WHERE colonia_id = ?
        AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stmt3->execute([$colonia_id]);
    $total = (int)$stmt3->fetchColumn();

    if ($total === 0) return -1;
    return round(($normales / $total) * 100, 1);
}

function actualizarKarma(PDO $db, int $usuario_id, int $colonia_id, string $estado): void {
    // Buscar si otros usuarios reportaron lo mismo en las últimas 2h
    $stmt = $db->prepare("
        SELECT estado, COUNT(*) as c FROM reportes_estado
        WHERE colonia_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 2 HOUR)
        AND usuario_id != ?
        GROUP BY estado ORDER BY c DESC LIMIT 1
    ");
    $stmt->execute([$colonia_id, $usuario_id]);
    $mayoria = $stmt->fetch();

    if ($mayoria) {
        $delta = ($mayoria['estado'] === $estado) ? 5 : -3;
        $db->prepare("UPDATE usuarios SET karma = GREATEST(0, karma + ?) WHERE id = ?")->execute([$delta, $usuario_id]);
        // Actualizar nivel
        $stmt2 = $db->prepare("SELECT karma FROM usuarios WHERE id = ?");
        $stmt2->execute([$usuario_id]);
        $karma = (int)$stmt2->fetchColumn();
        $nivel = 'nuevo';
        if ($karma >= 500) $nivel = 'experto';
        elseif ($karma >= 200) $nivel = 'confiable';
        elseif ($karma >= 50) $nivel = 'basico';
        $db->prepare("UPDATE usuarios SET nivel_reputacion = ? WHERE id = ?")->execute([$nivel, $usuario_id]);
    }
}

function generarNotificaciones(PDO $db, int $colonia_id): void {
    // Contar reportes "sin_agua" en últimas 2h
    $stmt = $db->prepare("SELECT COUNT(*) FROM reportes_estado WHERE colonia_id = ? AND estado = 'sin_agua' AND created_at >= DATE_SUB(NOW(), INTERVAL 2 HOUR)");
    $stmt->execute([$colonia_id]);
    $count = (int)$stmt->fetchColumn();

    if ($count >= 3) {
        // Verificar si hay tandeo ahora
        $diaNow = (int)date('w'); // 0=Dom
        $horaNow = date('H:i:s');
        $stmt2 = $db->prepare("SELECT id FROM tandeos WHERE colonia_id = ? AND dia_semana = ? AND hora_inicio <= ? AND hora_fin >= ? AND activo = 1");
        $stmt2->execute([$colonia_id, $diaNow, $horaNow, $horaNow]);
        $enTandeo = $stmt2->fetch();

        if (!$enTandeo) {
            // Notificar a usuarios que tienen esta colonia como favorita
            $stmt3 = $db->prepare("SELECT f.usuario_id, c.nombre FROM favoritos f JOIN colonias c ON c.id = f.colonia_id WHERE f.colonia_id = ?");
            $stmt3->execute([$colonia_id]);
            $favs = $stmt3->fetchAll();

            foreach ($favs as $fav) {
                // Evitar duplicar notificaciones recientes
                $stmt4 = $db->prepare("SELECT id FROM notificaciones WHERE usuario_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR) AND mensaje LIKE ?");
                $stmt4->execute([$fav['usuario_id'], '%' . $fav['nombre'] . '%']);
                if (!$stmt4->fetch()) {
                    $msg = "⚠️ Múltiples reportes de Sin Agua en {$fav['nombre']} fuera del horario de tandeo.";
                    $db->prepare("INSERT INTO notificaciones (usuario_id, mensaje) VALUES (?, ?)")->execute([$fav['usuario_id'], $msg]);
                }
            }
        }
    }
}
